package com.example.bottomnavigationmenudemo;

import android.content.Context;
import android.gesture.Prediction;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class HomeFragment extends Fragment implements View.OnClickListener {

    Context context;
    Heart heart;
    TextView textTarget;
    EditText editTextAge;
    EditText editTextSex;
    EditText editTextCP;
    EditText editTextTrestBps;
    EditText editTextChol;
    EditText editTextFbs;
    EditText editTextRestEcg;
    EditText editTextThalach;
    EditText editTextExang;
    EditText editTextOldPeak;
    EditText editTextSlope;
    EditText editTextCa;
    EditText editTextThal;

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getActivity().setTitle("CardioVascular Prognosis");

        heart = new Heart();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        this.context = container.getContext();

        editTextAge = view.findViewById(R.id.editTextAge);
        editTextSex = view.findViewById(R.id.editTextSex);
        editTextCP = view.findViewById(R.id.editTextCP);
        editTextTrestBps = view.findViewById(R.id.editTextTrestBps);
        editTextChol = view.findViewById(R.id.editTextChol);
        editTextFbs = view.findViewById(R.id.editTextFbs);
        editTextRestEcg = view.findViewById(R.id.editTextRestEcg);
        editTextThalach = view.findViewById(R.id.editTextThalach);
        editTextExang = view.findViewById(R.id.editTextExang);
        editTextOldPeak = view.findViewById(R.id.editTextOldPeak);
        editTextSlope = view.findViewById(R.id.editTextSlope);
        editTextCa = view.findViewById(R.id.editTextCa);
        editTextThal = view.findViewById(R.id.editTextThal);
        textTarget = view.findViewById(R.id.textTarget);

        Button btnPredictDisease = view.findViewById(R.id.btnPredictDisease);
        btnPredictDisease.setOnClickListener(this);

        return view;
    }


    private void getPredictDisease() {

        String url = "http://ec2-54-205-48-0.compute-1.amazonaws.com/predictDisease?";
        url += "age=" + heart.age + "&";
        url += "sex=" + heart.sex + "&";
        url += "cp=" + heart.cp + "&";
        url += "trestbps=" + heart.trestbps + "&";
        url += "chol=" + heart.chol + "&";
        url += "fbs=" + heart.fbs + "&";
        url += "restecg=" + heart.restecg + "&";
        url += "thalach=" + heart.thalach + "&";
        url += "exang=" + heart.exang + "&";
        url += "oldpeak=" + heart.oldpeak + "&";
        url += "slope=" + heart.slope + "&";
        url += "ca=" + heart.ca + "&";
        url += "thal=" + heart.thal;

        // creating a new variable for our request queue
        RequestQueue queue = Volley.newRequestQueue(context);

        // make json array request and then extracting data from each json object.
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject responseObj = response.getJSONObject(0);

                    String returnValue = responseObj.getString("target");
                    textTarget.setText("target: $" + returnValue);

                    if (returnValue.equals('1')) {
                        textTarget.setText("you  dont have disease");
                    } else {
                        textTarget.setText("you  have heart disease");
                    }
                    Toast.makeText(context, returnValue, Toast.LENGTH_SHORT).show();


                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Fail to get the data..", Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(jsonArrayRequest);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnPredictDisease:
                heart.age = editTextAge.getText().toString();
                heart.sex = editTextSex.getText().toString();
                heart.cp = editTextCP.getText().toString();
                heart.trestbps = editTextTrestBps.getText().toString();
                heart.chol = editTextChol.getText().toString();
                heart.fbs = editTextFbs.getText().toString();
                heart.restecg = editTextRestEcg.getText().toString();
                heart.thalach = editTextThalach.getText().toString();
                heart.exang = editTextExang.getText().toString();
                heart.oldpeak = editTextOldPeak.getText().toString();
                heart.slope = editTextSlope.getText().toString();
                heart.ca = editTextCa.getText().toString();
                heart.thal = editTextThal.getText().toString();
                getPredictDisease();
                textTarget.setText("wait..");
                break;
        }
    }
}
