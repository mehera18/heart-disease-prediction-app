package com.example.bottomnavigationmenudemo;

public class Heart {
    public String age;
    public String sex;
    public String cp;
    public String trestbps;
    public String chol;
    public String fbs;
    public String restecg;
    public String thalach;
    public String exang;
    public String oldpeak;
    public String slope;
    public String ca;
    public String thal;


}

